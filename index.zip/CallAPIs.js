var https = require('https');

module.exports = {
    searchForRecipe: function(searchTerm, callback) {
        searchResponse = "";
        callback(searchResponse);
    }
};

